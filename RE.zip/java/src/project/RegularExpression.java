import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionsExample {

    public static void main(String[] args) {
        
        simplePatternMatching();
        capturingGroupsExample();
    }

    private static void simplePatternMatching() {
        String text = "The quick brown fox jumps over the lazy dog.";

        String patternString = "fox";

        Pattern pattern = Pattern.compile(patternString);

        Matcher matcher = pattern.matcher(text);

        if (matcher.find()) {
            System.out.println("Pattern found: " + matcher.group());
        } else {
            System.out.println("Pattern not found.");
        }
    }

    private static void capturingGroupsExample() {
        String text = "John's phone number is 123-456-7890. Mary's number is 987-654-3210.";

     
        String patternString = "(\\d{3})-(\\d{3})-(\\d{4})";

       
        Pattern pattern = Pattern.compile(patternString);

        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Full match: " + matcher.group(0));
            System.out.println("Area code: " + matcher.group(1));
            System.out.println("Prefix: " + matcher.group(2));
            System.out.println("Suffix: " + matcher.group(3));
        }
    }
}